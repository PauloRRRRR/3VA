package Q3;

public class SomaMatriz implements Runnable{

    private int[][] matriz;
    private int threadId;
    private int totalSum;

    public SomaMatriz(int[][] arr, int threadId){
        this.matriz = arr;
        this.threadId = threadId;
        this.setSomaTotal(0);
    }

    @Override
    public void run() {
        int matrizColuna = matriz[0].length;
        int matrizLinha = matriz.length;
        int geraColuna = (int)((threadId %2) * (matrizColuna/2));
        int geraLinha = (int)((int)(threadId /2) * (matrizLinha/2));
        int finalColuna = geraColuna + (int)(matrizColuna/2);
        int finalLinha = geraLinha + (int)(matrizLinha/2);

        for(int i = geraColuna; i < finalColuna; i++){
            for(int j = geraLinha; j < finalLinha; j++){
                setSomaTotal(getSomaTotal() + matriz[j][i]);
            }
        }
    }

    public int getSomaTotal() {
        return totalSum;
    }

    public void setSomaTotal(int totalSum) {
        this.totalSum = totalSum;
    }

}