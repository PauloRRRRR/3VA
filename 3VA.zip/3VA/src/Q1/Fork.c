#include <sys/types.h>
        #include <sys/wait.h>
        #include <stdio.h>
        #include <unistd.h>


        int main() {

        if (fork())
        if (fork())
        printf("Processo Pai\n and my ID is %d and my parent ID is %d\n", getpid(), getppid());

        else
        printf("Processo F1\n and my ID is %d and my parent ID is %d\n", getpid(), getppid());
        else
        if(fork())
        if(fork())
        if(fork())
        printf("Processo F2\n and my ID is %d and my parent ID is %d\n", getpid(), getppid());
        else
        printf("Processo F6\n and my ID is %d and my parent ID is %d\n", getpid(), getppid());

        else
        if(fork())
        printf("Processo F4\n and my ID is %d and my parent ID is %d\n", getpid(), getppid());
        else
        printf("Processo F5\n and my ID is %d and my parent ID is %d\n", getpid(), getppid());
        //if(fork();



        return 0;
        }